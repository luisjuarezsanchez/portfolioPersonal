<?php $__env->startSection('title','Portafolio profesional'); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luis/Documentos/LaravelProjects/portafolio/portfoliopersonal/resources/views/inicio.blade.php ENDPATH**/ ?>