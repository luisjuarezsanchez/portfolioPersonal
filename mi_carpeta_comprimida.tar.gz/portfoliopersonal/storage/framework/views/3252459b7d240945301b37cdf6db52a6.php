<footer class="bg-body-tertiary text-center text-lg-start container-footer">
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
        <p class="text-center px-5">© Ing. Luis Jair Juárez Sánchez<br> Será un gusto trabajar juntos</p>
    </div>
    <!-- Copyright -->
</footer>
<?php /**PATH /home/luis/Documentos/LaravelProjects/portafolio/portfoliopersonal/resources/views/layouts/_partials/footer.blade.php ENDPATH**/ ?>